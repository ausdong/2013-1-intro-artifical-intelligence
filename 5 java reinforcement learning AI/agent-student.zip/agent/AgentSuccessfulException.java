// $Id: AgentSuccessfulException.java 1622 2013-03-20 04:27:33Z cengiz $

package agent;

import agent.*;
import grid.*;
import block.*;
import iface.*;

public class AgentSuccessfulException extends Exception {
  public AgentSuccessfulException(String s) { super(s); }
}
