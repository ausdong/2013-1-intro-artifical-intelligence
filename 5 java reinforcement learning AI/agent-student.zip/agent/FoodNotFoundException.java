// $Id: FoodNotFoundException.java 1622 2013-03-20 04:27:33Z cengiz $

package agent;

import agent.*;
import grid.*;
import block.*;
import iface.*;

public class FoodNotFoundException extends Exception {
  FoodNotFoundException(String s) { super(s); }
}
